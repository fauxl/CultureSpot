package Culture;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;


public class LibraryWrapper {

    public static Collection<MuseoBean> Wrapper(String arg) throws IOException {

        // Make a URL to the web page
        URL url = new URL("https://www.librerie.it/librerie");

        // Get the input stream through URL Connection
        URLConnection con = url.openConnection();
        InputStream is =con.getInputStream();

        // Once you have the Input Stream, it's just plain old Java IO stuff.

        // For this case, since you are interested in getting plain-text web page
        // I'll use a reader and output the text content to System.out.

        // For binary content, it's better to directly read the bytes from stream and write
        // to the target file.


        BufferedReader br = new BufferedReader(new InputStreamReader(is));

        String lin = null;
        String line = null;
        String line2 = null;
        String code = ">"+arg+"<";
		Collection<MuseoBean> musei = new LinkedList<MuseoBean>();
        
        // read each line and write to System.out
        while ((lin = br.readLine()) != null) {

            if(lin.toLowerCase().contains(code.toLowerCase())){

            	int index1 = lin.lastIndexOf("href") + 6;
            	int index2= lin.lastIndexOf("\" ");
            	int m=1;
                

            	//System.out.println(index2);
            	//System.out.println("https://www.librerie.it" + line.substring(index1,index2));
            for(int j=0;j<m;j++) {
                URL url2 = new URL("https://www.librerie.it" + lin.substring(index1,index2)+"?page="+j);
                //System.out.println(url2);
                URLConnection con2 = url2.openConnection();
                InputStream is2 =con2.getInputStream();
                BufferedReader br2 = new BufferedReader(new InputStreamReader(is2));
				while ((line = br2.readLine()) != null) {

                	MuseoBean bean = new MuseoBean();
                	int in3=-1;
                	in3 = line.lastIndexOf("title=\"Vai all&#039;ultima pagina\"");
                	
                	if(in3!=-1) {
                		if(line.substring(in3-4,in3-2).contains("=")){
                   m = Integer.parseInt(line.substring(in3-3,in3-2)) +1;
                		} else
                            m = Integer.parseInt(line.substring(in3-4,in3-2)) +1;

                		}
                	

                	int in1 = line.lastIndexOf("\">") + 2;
                	int in2= line.lastIndexOf("</a>          </td>"); 
                	if(in1!=1 && in2!=-1) {
        				boolean yes = false;

    				bean.setNome(line.substring(in1,in2));
    				bean.setProvincia(arg);
                	
                    while ((line2 = br2.readLine()) != null && yes == false) {

                    	int in4= line2.lastIndexOf("          </td>"); 
                    	if (in4!=-1 && in4<40 && in4!=16) {
                    		yes = true;
					
                	bean.setAddress(line2.substring(11,in4));
    				musei.add(bean);
           //     System.out.println(bean.toString());
                	}}
                    
                    
                    
                	}
                	              }
                
           
            } 
            	
            }
            
        } return musei;
    }
}